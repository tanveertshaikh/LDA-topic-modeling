========================
``# LDA Topic Modeling`` - Topic Modeling in Python with NLTK and Gensim
========================

### Dataset Link
https://data.world/elenadata/vox-articles

### Github repo link
https://github.com/tanveertshaikh/LDA-topic-modeling

====================================
### Instructions for Code Execution:
====================================

::

	- Find the bash script in the /bin folder 
	- Run ‘sh run.sh’ in the bash shell or your preferred shell
